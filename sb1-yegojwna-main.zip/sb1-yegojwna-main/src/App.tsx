import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import InstituteLogin from './pages/InstituteLogin';
import InstituteDashboard from './pages/InstituteDashboard';
import RequestForm from './pages/RequestForm';
import DeliveryTracking from './pages/DeliveryTracking';
import VolunteerRequests from './pages/VolunteerRequests';
import FeedbackForm from './pages/FeedbackForm';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/institute/login" element={<InstituteLogin />} />
        <Route path="/institute/dashboard" element={<InstituteDashboard />} />
        <Route path="/institute/request-form" element={<RequestForm />} />
        <Route path="/institute/delivery-tracking/:id" element={<DeliveryTracking />} />
        <Route path="/institute/volunteer-requests" element={<VolunteerRequests />} />
        <Route path="/institute/feedback/:id" element={<FeedbackForm />} />
      </Routes>
    </Router>
  );
}

export default App;