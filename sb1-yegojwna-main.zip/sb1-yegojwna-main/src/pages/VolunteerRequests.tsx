import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Calendar, Clock, Briefcase, PlusCircle, X, Edit, Trash } from 'lucide-react';
import Navbar from '../components/Navbar';

// Mock data for existing volunteer requests
const mockVolunteerRequests = [
  {
    id: 'vol-1',
    title: 'Art & Craft Workshop',
    date: '2025-06-10',
    time: '10:00 - 12:00',
    skills: ['Art', 'Creativity', 'Teaching'],
    description: 'Looking for volunteers to conduct an art and craft workshop for children aged 8-12. Materials will be provided.',
    volunteers_needed: 3,
    volunteers_applied: 1
  },
  {
    id: 'vol-2',
    title: 'Math Tutoring',
    date: '2025-06-15',
    time: '16:00 - 18:00',
    skills: ['Mathematics', 'Teaching', 'Patience'],
    description: 'Need tutors to help children with basic mathematics. Focus on ages 10-14.',
    volunteers_needed: 2,
    volunteers_applied: 0
  },
  {
    id: 'vol-3',
    title: 'Sports Day Assistance',
    date: '2025-06-20',
    time: '09:00 - 16:00',
    skills: ['Sports', 'Coaching', 'First Aid'],
    description: 'Volunteers needed to help organize and supervise various sports activities during our annual sports day.',
    volunteers_needed: 5,
    volunteers_applied: 3
  }
];

const VolunteerRequests: React.FC = () => {
  const navigate = useNavigate();
  const [volunteerRequests, setVolunteerRequests] = useState(mockVolunteerRequests);
  const [showNewRequestForm, setShowNewRequestForm] = useState(false);
  const [editingRequestId, setEditingRequestId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    title: '',
    date: '',
    time: '',
    skills: [''],
    description: '',
    volunteers_needed: 1
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSkillChange = (index: number, value: string) => {
    const updatedSkills = [...formData.skills];
    updatedSkills[index] = value;
    setFormData(prev => ({ ...prev, skills: updatedSkills }));
  };

  const addSkill = () => {
    setFormData(prev => ({ ...prev, skills: [...prev.skills, ''] }));
  };

  const removeSkill = (index: number) => {
    if (formData.skills.length > 1) {
      const updatedSkills = [...formData.skills];
      updatedSkills.splice(index, 1);
      setFormData(prev => ({ ...prev, skills: updatedSkills }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Filter out empty skills
    const filteredSkills = formData.skills.filter(skill => skill.trim() !== '');
    
    if (editingRequestId) {
      // Update existing request
      setVolunteerRequests(prev => 
        prev.map(req => 
          req.id === editingRequestId 
            ? { 
                ...req, 
                title: formData.title,
                date: formData.date,
                time: formData.time,
                skills: filteredSkills,
                description: formData.description,
                volunteers_needed: Number(formData.volunteers_needed)
              } 
            : req
        )
      );
      setEditingRequestId(null);
    } else {
      // Add new request
      const newRequest = {
        id: `vol-${Date.now()}`,
        title: formData.title,
        date: formData.date,
        time: formData.time,
        skills: filteredSkills,
        description: formData.description,
        volunteers_needed: Number(formData.volunteers_needed),
        volunteers_applied: 0
      };
      
      setVolunteerRequests(prev => [...prev, newRequest]);
    }
    
    // Reset form
    setFormData({
      title: '',
      date: '',
      time: '',
      skills: [''],
      description: '',
      volunteers_needed: 1
    });
    
    setShowNewRequestForm(false);
  };

  const handleEdit = (id: string) => {
    const requestToEdit = volunteerRequests.find(req => req.id === id);
    if (requestToEdit) {
      setFormData({
        title: requestToEdit.title,
        date: requestToEdit.date,
        time: requestToEdit.time,
        skills: [...requestToEdit.skills],
        description: requestToEdit.description,
        volunteers_needed: requestToEdit.volunteers_needed
      });
      setEditingRequestId(id);
      setShowNewRequestForm(true);
    }
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this volunteer request?')) {
      setVolunteerRequests(prev => prev.filter(req => req.id !== id));
    }
  };

  const cancelForm = () => {
    setShowNewRequestForm(false);
    setEditingRequestId(null);
    setFormData({
      title: '',
      date: '',
      time: '',
      skills: [''],
      description: '',
      volunteers_needed: 1
    });
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar userType="institute" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="bg-red-600 p-6">
            <div className="flex justify-between items-center">
              <h1 className="text-2xl font-bold text-white flex items-center">
                <Users className="h-6 w-6 mr-2" />
                Volunteer Requests
              </h1>
              
              <button
                onClick={() => setShowNewRequestForm(!showNewRequestForm)}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-red-600 bg-white hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                {showNewRequestForm ? (
                  <>
                    <X className="h-4 w-4 mr-1" />
                    Cancel
                  </>
                ) : (
                  <>
                    <PlusCircle className="h-4 w-4 mr-1" />
                    New Request
                  </>
                )}
              </button>
            </div>
            <p className="text-red-100 mt-1">
              Create and manage volunteer opportunities for your institution
            </p>
          </div>
          
          {/* New Request Form */}
          {showNewRequestForm && (
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-semibold mb-4">
                {editingRequestId ? 'Edit Volunteer Request' : 'Create New Volunteer Request'}
              </h2>
              
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  {/* Title */}
                  <div>
                    <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                      Title
                    </label>
                    <input
                      type="text"
                      id="title"
                      name="title"
                      value={formData.title}
                      onChange={handleChange}
                      required
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                      placeholder="e.g., Art Workshop, Sports Day Help"
                    />
                  </div>
                  
                  {/* Volunteers Needed */}
                  <div>
                    <label htmlFor="volunteers_needed" className="block text-sm font-medium text-gray-700 mb-1">
                      Volunteers Needed
                    </label>
                    <input
                      type="number"
                      id="volunteers_needed"
                      name="volunteers_needed"
                      value={formData.volunteers_needed}
                      onChange={handleChange}
                      min="1"
                      required
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                    />
                  </div>
                  
                  {/* Date */}
                  <div>
                    <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">
                      Date
                    </label>
                    <input
                      type="date"
                      id="date"
                      name="date"
                      value={formData.date}
                      onChange={handleChange}
                      min={new Date().toISOString().split('T')[0]}
                      required
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                    />
                  </div>
                  
                  {/* Time */}
                  <div>
                    <label htmlFor="time" className="block text-sm font-medium text-gray-700 mb-1">
                      Time
                    </label>
                    <input
                      type="text"
                      id="time"
                      name="time"
                      value={formData.time}
                      onChange={handleChange}
                      required
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                      placeholder="e.g., 10:00 - 12:00"
                    />
                  </div>
                </div>
                
                {/* Skills */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Required Skills
                  </label>
                  
                  {formData.skills.map((skill, index) => (
                    <div key={index} className="flex mb-2">
                      <input
                        type="text"
                        value={skill}
                        onChange={(e) => handleSkillChange(index, e.target.value)}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                        placeholder="e.g., Teaching, Art, Sports"
                      />
                      
                      <button
                        type="button"
                        onClick={() => removeSkill(index)}
                        className="ml-2 inline-flex items-center p-1 border border-transparent rounded-md text-red-600 hover:bg-red-50 focus:outline-none"
                      >
                        <X className="h-5 w-5" />
                      </button>
                    </div>
                  ))}
                  
                  <button
                    type="button"
                    onClick={addSkill}
                    className="mt-1 text-sm text-red-600 hover:text-red-800"
                  >
                    + Add Another Skill
                  </button>
                </div>
                
                {/* Description */}
                <div className="mb-6">
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    id="description"
                    name="description"
                    rows={3}
                    value={formData.description}
                    onChange={handleChange}
                    required
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                    placeholder="Describe the volunteer opportunity, requirements, and what volunteers will be doing..."
                  />
                </div>
                
                {/* Submit Buttons */}
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={cancelForm}
                    className="mr-3 inline-flex justify-center py-2 px-4 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                  >
                    {editingRequestId ? 'Update Request' : 'Create Request'}
                  </button>
                </div>
              </form>
            </div>
          )}
          
          {/* Volunteer Requests List */}
          <div className="p-6">
            {volunteerRequests.length > 0 ? (
              <div className="space-y-6">
                {volunteerRequests.map(request => (
                  <div key={request.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                    <div className="flex justify-between items-start">
                      <h3 className="text-lg font-semibold text-gray-900">{request.title}</h3>
                      
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleEdit(request.id)}
                          className="p-1 text-gray-500 hover:text-gray-700"
                        >
                          <Edit className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => handleDelete(request.id)}
                          className="p-1 text-red-500 hover:text-red-700"
                        >
                          <Trash className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                    
                    <div className="mt-2 grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="flex items-center text-sm text-gray-600">
                        <Calendar className="h-4 w-4 mr-2 text-red-500" />
                        {request.date}
                      </div>
                      
                      <div className="flex items-center text-sm text-gray-600">
                        <Clock className="h-4 w-4 mr-2 text-red-500" />
                        {request.time}
                      </div>
                      
                      <div className="flex items-center text-sm text-gray-600">
                        <Users className="h-4 w-4 mr-2 text-red-500" />
                        {request.volunteers_applied} / {request.volunteers_needed} volunteers
                      </div>
                    </div>
                    
                    <p className="mt-3 text-gray-700">{request.description}</p>
                    
                    <div className="mt-4">
                      <h4 className="text-sm font-medium text-gray-700 flex items-center">
                        <Briefcase className="h-4 w-4 mr-1 text-gray-500" />
                        Required Skills:
                      </h4>
                      <div className="mt-1 flex flex-wrap gap-2">
                        {request.skills.map((skill, index) => (
                          <span 
                            key={index}
                            className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Users className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                <h3 className="text-lg font-medium text-gray-900">No volunteer requests yet</h3>
                <p className="mt-1 text-gray-500">
                  Create your first volunteer request to get help from donors.
                </p>
                <button
                  onClick={() => setShowNewRequestForm(true)}
                  className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  <PlusCircle className="h-4 w-4 mr-1" />
                  Create Request
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VolunteerRequests;