import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Package, Truck, MapPin, Clock, CheckCircle, Phone } from 'lucide-react';
import Navbar from '../components/Navbar';
import DeliveryMap from '../components/DeliveryMap';

// Mock data for the delivery
const mockDeliveryData = {
  'del-123456': {
    id: 'del-123456',
    status: 'in-progress',
    items: ['Rice', 'Lentils', 'Cooking Oil'],
    quantity: '25kg',
    supplier: {
      name: 'GroceryMart',
      address: '456 Market St, Cityville',
      phone: '+1 (555) 123-4567',
      location: { lat: 40.7128, lng: -74.0060 }
    },
    transporter: {
      name: 'John Doe',
      vehicle: 'White Toyota Corolla',
      licensePlate: 'ABC-1234',
      phone: '+1 (555) 987-6543',
      location: { lat: 40.7200, lng: -74.0100 },
      eta: '15 minutes'
    },
    institute: {
      name: 'Sunshine Orphanage',
      address: '123 Main St, Cityville',
      location: { lat: 40.7300, lng: -74.0060 }
    },
    estimatedDelivery: 'Today, 3:30 PM',
    otp: '4567'
  },
  'del-123457': {
    id: 'del-123457',
    status: 'pending',
    items: ['Notebooks', 'Pencils', 'Erasers'],
    quantity: '50 sets',
    supplier: {
      name: 'SchoolSupplies Co.',
      address: '789 Education Ave, Cityville',
      phone: '+1 (555) 234-5678',
      location: { lat: 40.7150, lng: -74.0080 }
    },
    institute: {
      name: 'Sunshine Orphanage',
      address: '123 Main St, Cityville',
      location: { lat: 40.7300, lng: -74.0060 }
    },
    estimatedDelivery: 'Tomorrow, 10:00 AM'
  }
};

const DeliveryTracking: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [delivery, setDelivery] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [otpVerified, setOtpVerified] = useState(false);
  const [enteredOtp, setEnteredOtp] = useState('');
  
  useEffect(() => {
    // Simulate API call to fetch delivery data
    setTimeout(() => {
      if (id && mockDeliveryData[id as keyof typeof mockDeliveryData]) {
        setDelivery(mockDeliveryData[id as keyof typeof mockDeliveryData]);
      }
      setLoading(false);
    }, 1000);
  }, [id]);

  const verifyOtp = () => {
    if (delivery && enteredOtp === delivery.otp) {
      setOtpVerified(true);
    } else {
      alert('Invalid OTP. Please try again.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100">
        <Navbar userType="institute" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-red-500"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!delivery) {
    return (
      <div className="min-h-screen bg-gray-100">
        <Navbar userType="institute" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Delivery Not Found</h1>
            <p className="text-gray-600">
              The delivery you're looking for doesn't exist or has been removed.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar userType="institute" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="bg-red-600 p-6">
            <h1 className="text-2xl font-bold text-white flex items-center">
              <Truck className="h-6 w-6 mr-2" />
              Tracking Delivery #{delivery.id.slice(-6)}
            </h1>
            <p className="text-red-100 mt-1">
              {delivery.status === 'in-progress' 
                ? 'Your delivery is on the way!' 
                : delivery.status === 'pending' 
                  ? 'Your delivery is being prepared' 
                  : 'Your delivery has been completed'}
            </p>
          </div>
          
          <div className="p-6">
            {/* Delivery Status */}
            <div className="mb-8">
              <h2 className="text-lg font-semibold mb-4">Delivery Status</h2>
              
              <div className="relative">
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                
                <div className="relative flex justify-between">
                  <div className="flex flex-col items-center">
                    <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                      delivery.status !== 'pending' ? 'bg-green-500' : 'bg-gray-300'
                    } text-white`}>
                      <CheckCircle className="h-5 w-5" />
                    </div>
                    <p className="mt-2 text-sm text-gray-500">Confirmed</p>
                  </div>
                  
                  <div className="flex flex-col items-center">
                    <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                      delivery.status !== 'pending' ? 'bg-green-500' : 'bg-gray-300'
                    } text-white`}>
                      <Package className="h-5 w-5" />
                    </div>
                    <p className="mt-2 text-sm text-gray-500">Prepared</p>
                  </div>
                  
                  <div className="flex flex-col items-center">
                    <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                      delivery.status === 'in-progress' ? 'bg-blue-500' : 
                      delivery.status === 'completed' ? 'bg-green-500' : 'bg-gray-300'
                    } text-white`}>
                      <Truck className="h-5 w-5" />
                    </div>
                    <p className="mt-2 text-sm text-gray-500">In Transit</p>
                  </div>
                  
                  <div className="flex flex-col items-center">
                    <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                      delivery.status === 'completed' ? 'bg-green-500' : 'bg-gray-300'
                    } text-white`}>
                      <CheckCircle className="h-5 w-5" />
                    </div>
                    <p className="mt-2 text-sm text-gray-500">Delivered</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 text-center">
                <p className="text-lg font-medium">
                  {delivery.status === 'in-progress' 
                    ? `Estimated arrival: ${delivery.transporter?.eta || 'Soon'}` 
                    : delivery.status === 'pending' 
                      ? `Expected delivery: ${delivery.estimatedDelivery}` 
                      : 'Delivery completed'}
                </p>
              </div>
            </div>
            
            {/* Delivery Map */}
            {delivery.status === 'in-progress' && (
              <div className="mb-8">
                <h2 className="text-lg font-semibold mb-4">Live Tracking</h2>
                <DeliveryMap 
                  supplierLocation={{
                    lat: delivery.supplier.location.lat,
                    lng: delivery.supplier.location.lng,
                    name: delivery.supplier.name,
                    type: 'supplier'
                  }}
                  instituteLocation={{
                    lat: delivery.institute.location.lat,
                    lng: delivery.institute.location.lng,
                    name: delivery.institute.name,
                    type: 'institute'
                  }}
                  transporterLocation={{
                    lat: delivery.transporter.location.lat,
                    lng: delivery.transporter.location.lng,
                    name: delivery.transporter.name,
                    type: 'transporter'
                  }}
                  estimatedArrival={delivery.transporter.eta}
                />
              </div>
            )}
            
            {/* Delivery Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-gray-50 p-4 rounded-md">
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <Package className="h-5 w-5 mr-2 text-red-500" />
                  Items
                </h3>
                <ul className="space-y-2">
                  {delivery.items.map((item: string, index: number) => (
                    <li key={index} className="text-gray-700">
                      • {item}
                    </li>
                  ))}
                </ul>
                <p className="mt-2 text-gray-700">
                  <strong>Quantity:</strong> {delivery.quantity}
                </p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-md">
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <MapPin className="h-5 w-5 mr-2 text-red-500" />
                  Supplier
                </h3>
                <p className="text-gray-700">{delivery.supplier.name}</p>
                <p className="text-gray-700">{delivery.supplier.address}</p>
                <p className="text-gray-700 flex items-center mt-2">
                  <Phone className="h-4 w-4 mr-1 text-gray-500" />
                  {delivery.supplier.phone}
                </p>
              </div>
            </div>
            
            {/* Transporter Details */}
            {delivery.transporter && (
              <div className="bg-gray-50 p-4 rounded-md mb-8">
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <Truck className="h-5 w-5 mr-2 text-red-500" />
                  Transporter
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-700"><strong>Name:</strong> {delivery.transporter.name}</p>
                    <p className="text-gray-700"><strong>Vehicle:</strong> {delivery.transporter.vehicle}</p>
                    <p className="text-gray-700"><strong>License Plate:</strong> {delivery.transporter.licensePlate}</p>
                  </div>
                  <div>
                    <p className="text-gray-700 flex items-center">
                      <Phone className="h-4 w-4 mr-1 text-gray-500" />
                      {delivery.transporter.phone}
                    </p>
                    <p className="text-gray-700 flex items-center mt-2">
                      <Clock className="h-4 w-4 mr-1 text-gray-500" />
                      <strong>ETA:</strong> {delivery.transporter.eta}
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            {/* OTP Verification */}
            {delivery.status === 'in-progress' && delivery.otp && (
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-md mb-8">
                <h3 className="font-semibold text-gray-900 mb-3">Delivery Verification</h3>
                
                {otpVerified ? (
                  <div className="text-green-600 flex items-center">
                    <CheckCircle className="h-5 w-5 mr-2" />
                    OTP verified successfully! You can accept the delivery when it arrives.
                  </div>
                ) : (
                  <>
                    <p className="text-gray-700 mb-3">
                      When the delivery arrives, verify the OTP with the transporter:
                    </p>
                    <div className="flex items-center">
                      <input
                        type="text"
                        value={enteredOtp}
                        onChange={(e) => setEnteredOtp(e.target.value)}
                        placeholder="Enter OTP"
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                      />
                      <button
                        onClick={verifyOtp}
                        className="ml-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                      >
                        Verify
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryTracking;