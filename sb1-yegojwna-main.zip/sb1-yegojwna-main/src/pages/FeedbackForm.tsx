import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Star, Package, User, Truck, MessageSquare } from 'lucide-react';
import Navbar from '../components/Navbar';

// Mock data for the delivery
const mockDeliveryData = {
  'del-123458': {
    id: 'del-123458',
    status: 'completed',
    items: ['T-shirts', 'Pants', 'Socks'],
    quantity: '30 sets',
    supplier: {
      id: 'sup-123',
      name: 'KidsClothing Store',
    },
    transporter: {
      id: 'trans-456',
      name: 'Michael Johnson',
    },
    donor: {
      id: 'don-789',
      name: 'Jane Smith',
    },
    deliveredAt: 'May 15, 2025, 2:45 PM',
  }
};

const FeedbackForm: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [delivery, setDelivery] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  const [supplierRating, setSupplierRating] = useState(0);
  const [supplierHover, setSupplierHover] = useState(0);
  const [supplierFeedback, setSupplierFeedback] = useState('');
  
  const [transporterRating, setTransporterRating] = useState(0);
  const [transporterHover, setTransporterHover] = useState(0);
  const [transporterFeedback, setTransporterFeedback] = useState('');
  
  const [donorFeedback, setDonorFeedback] = useState('');
  
  useEffect(() => {
    // Simulate API call to fetch delivery data
    setTimeout(() => {
      if (id && mockDeliveryData[id as keyof typeof mockDeliveryData]) {
        setDelivery(mockDeliveryData[id as keyof typeof mockDeliveryData]);
      }
      setLoading(false);
    }, 1000);
  }, [id]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real application, you would send this data to your backend
    console.log({
      deliveryId: id,
      supplierFeedback: {
        rating: supplierRating,
        comment: supplierFeedback
      },
      transporterFeedback: {
        rating: transporterRating,
        comment: transporterFeedback
      },
      donorFeedback
    });
    
    // Show success message and redirect
    alert('Thank you for your feedback!');
    navigate('/institute/dashboard');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100">
        <Navbar userType="institute" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-red-500"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!delivery) {
    return (
      <div className="min-h-screen bg-gray-100">
        <Navbar userType="institute" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Delivery Not Found</h1>
            <p className="text-gray-600">
              The delivery you're looking for doesn't exist or has been removed.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar userType="institute" />
      
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="bg-red-600 p-6">
            <h1 className="text-2xl font-bold text-white flex items-center">
              <MessageSquare className="h-6 w-6 mr-2" />
              Delivery Feedback
            </h1>
            <p className="text-red-100 mt-1">
              Share your experience about the delivery
            </p>
          </div>
          
          <div className="p-6">
            {/* Delivery Summary */}
            <div className="bg-gray-50 p-4 rounded-md mb-6">
              <h2 className="font-semibold text-gray-900 mb-2 flex items-center">
                <Package className="h-5 w-5 mr-2 text-red-500" />
                Delivery Summary
              </h2>
              <p className="text-gray-700"><strong>Items:</strong> {delivery.items.join(', ')}</p>
              <p className="text-gray-700"><strong>Quantity:</strong> {delivery.quantity}</p>
              <p className="text-gray-700"><strong>Delivered on:</strong> {delivery.deliveredAt}</p>
            </div>
            
            <form onSubmit={handleSubmit}>
              {/* Supplier Feedback */}
              <div className="mb-6">
                <h2 className="text-lg font-semibold mb-3 flex items-center">
                  <User className="h-5 w-5 mr-2 text-red-500" />
                  Supplier Feedback ({delivery.supplier.name})
                </h2>
                
                <div className="mb-3">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Rate the quality of items and service:
                  </label>
                  <div className="flex">
                    {[...Array(5)].map((_, index) => {
                      const ratingValue = index + 1;
                      return (
                        <label key={index} className="cursor-pointer">
                          <input
                            type="radio"
                            name="supplierRating"
                            value={ratingValue}
                            className="hidden"
                            onClick={() => setSupplierRating(ratingValue)}
                          />
                          <Star
                            className={`h-8 w-8 ${
                              ratingValue <= (supplierHover || supplierRating)
                                ? 'text-yellow-400 fill-current'
                                : 'text-gray-300'
                            }`}
                            onMouseEnter={() => setSupplierHover(ratingValue)}
                            onMouseLeave={() => setSupplierHover(0)}
                          />
                        </label>
                      );
                    })}
                  </div>
                </div>
                
                <div>
                  <label htmlFor="supplierFeedback" className="block text-sm font-medium text-gray-700 mb-1">
                    Comments about the supplier:
                  </label>
                  <textarea
                    id="supplierFeedback"
                    rows={3}
                    value={supplierFeedback}
                    onChange={(e) => setSupplierFeedback(e.target.value)}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                    placeholder="How was the quality of items? Were they as described? Any issues?"
                  />
                </div>
              </div>
              
              {/* Transporter Feedback */}
              <div className="mb-6">
                <h2 className="text-lg font-semibold mb-3 flex items-center">
                  <Truck className="h-5 w-5 mr-2 text-red-500" />
                  Transporter Feedback ({delivery.transporter.name})
                </h2>
                
                <div className="mb-3">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Rate the delivery service:
                  </label>
                  <div className="flex">
                    {[...Array(5)].map((_, index) => {
                      const ratingValue = index + 1;
                      return (
                        <label key={index} className="cursor-pointer">
                          <input
                            type="radio"
                            name="transporterRating"
                            value={ratingValue}
                            className="hidden"
                            onClick={() => setTransporterRating(ratingValue)}
                          />
                          <Star
                            className={`h-8 w-8 ${
                              ratingValue <= (transporterHover || transporterRating)
                                ? 'text-yellow-400 fill-current'
                                : 'text-gray-300'
                            }`}
                            onMouseEnter={() => setTransporterHover(ratingValue)}
                            onMouseLeave={() => setTransporterHover(0)}
                          />
                        </label>
                      );
                    })}
                  </div>
                </div>
                
                <div>
                  <label htmlFor="transporterFeedback" className="block text-sm font-medium text-gray-700 mb-1">
                    Comments about the transporter:
                  </label>
                  <textarea
                    id="transporterFeedback"
                    rows={3}
                    value={transporterFeedback}
                    onChange={(e) => setTransporterFeedback(e.target.value)}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                    placeholder="Was the delivery on time? Was the transporter professional? Any issues?"
                  />
                </div>
              </div>
              
              {/* Donor Feedback */}
              <div className="mb-6">
                <h2 className="text-lg font-semibold mb-3 flex items-center">
                  <User className="h-5 w-5 mr-2 text-red-500" />
                  Message to Donor ({delivery.donor.name})
                </h2>
                
                <div>
                  <label htmlFor="donorFeedback" className="block text-sm font-medium text-gray-700 mb-1">
                    Send a thank you message:
                  </label>
                  <textarea
                    id="donorFeedback"
                    rows={4}
                    value={donorFeedback}
                    onChange={(e) => setDonorFeedback(e.target.value)}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                    placeholder="Express your gratitude and share how this donation will help your institution..."
                  />
                </div>
              </div>
              
              {/* Submit Button */}
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => navigate('/institute/dashboard')}
                  className="mr-3 inline-flex justify-center py-2 px-4 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  Submit Feedback
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeedbackForm;