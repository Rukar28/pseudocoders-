import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Package, ShoppingBag, Users, Clock, Calendar, ChevronDown, ChevronUp, PlusCircle } from 'lucide-react';
import Navbar from '../components/Navbar';
import StatCard from '../components/StatCard';
import DeliveryCard from '../components/DeliveryCard';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, Title } from 'chart.js';
import { Doughnut, Line } from 'react-chartjs-2';

// Register ChartJS components
ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, Title);

// Mock data for the dashboard
const mockDeliveries = [
  {
    id: 'del-123456',
    status: 'in-progress' as const,
    items: ['Rice', 'Lentils', 'Cooking Oil'],
    quantity: '25kg',
    supplier: 'GroceryMart',
    estimatedDelivery: 'Today, 3:30 PM',
    address: '123 Main St, Cityville'
  },
  {
    id: 'del-123457',
    status: 'pending' as const,
    items: ['Notebooks', 'Pencils', 'Erasers'],
    quantity: '50 sets',
    supplier: 'SchoolSupplies Co.',
    estimatedDelivery: 'Tomorrow, 10:00 AM',
    address: '123 Main St, Cityville'
  },
  {
    id: 'del-123458',
    status: 'completed' as const,
    items: ['T-shirts', 'Pants', 'Socks'],
    quantity: '30 sets',
    supplier: 'KidsClothing Store',
    estimatedDelivery: 'Delivered on May 15, 2:45 PM',
    address: '123 Main St, Cityville'
  }
];

const InstituteDashboard: React.FC = () => {
  const [showPendingDeliveries, setShowPendingDeliveries] = useState(true);
  const [showCompletedDeliveries, setShowCompletedDeliveries] = useState(false);
  
  // Filter deliveries based on status
  const pendingDeliveries = mockDeliveries.filter(d => d.status === 'pending' || d.status === 'in-progress');
  const completedDeliveries = mockDeliveries.filter(d => d.status === 'completed');

  // Data for donation type distribution chart
  const donationTypeData = {
    labels: ['Groceries', 'Clothing', 'School Supplies', 'Medications', 'Meals'],
    datasets: [
      {
        label: 'Donation Types',
        data: [35, 25, 20, 10, 10],
        backgroundColor: [
          'rgba(255, 99, 132, 0.7)',
          'rgba(54, 162, 235, 0.7)',
          'rgba(255, 206, 86, 0.7)',
          'rgba(75, 192, 192, 0.7)',
          'rgba(153, 102, 255, 0.7)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  // Data for monthly donations trend chart
  const monthlyDonationsData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Donations Received',
        data: [12, 19, 15, 17, 22, 25],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.5)',
        tension: 0.3,
      },
      {
        label: 'Requests Made',
        data: [15, 20, 18, 19, 24, 28],
        borderColor: 'rgb(53, 162, 235)',
        backgroundColor: 'rgba(53, 162, 235, 0.5)',
        tension: 0.3,
      },
    ],
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar userType="institute" />
      
      <div className="dashboard-bg py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-white mb-8">
            <h1 className="text-3xl font-bold">Sunshine Orphanage Dashboard</h1>
            <p className="mt-2">Manage your donations, requests, and volunteer activities</p>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard 
            title="Total Donations" 
            value="156" 
            icon={Package} 
            color="bg-red-500" 
          />
          <StatCard 
            title="Pending Requests" 
            value="8" 
            icon={ShoppingBag} 
            color="bg-blue-500" 
          />
          <StatCard 
            title="Volunteer Requests" 
            value="12" 
            icon={Users} 
            color="bg-green-500" 
          />
          <StatCard 
            title="Upcoming Deliveries" 
            value="5" 
            icon={Clock} 
            color="bg-purple-500" 
          />
        </div>
        
        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold mb-4">Donation Type Distribution</h3>
            <div className="h-64">
              <Doughnut 
                data={donationTypeData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'right',
                    }
                  }
                }} 
              />
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold mb-4">Monthly Donations Trend</h3>
            <div className="h-64">
              <Line 
                data={monthlyDonationsData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'top',
                    }
                  },
                  scales: {
                    y: {
                      beginAtZero: true
                    }
                  }
                }} 
              />
            </div>
          </div>
        </div>
        
        {/* Create Request Button */}
        <div className="mb-8">
          <Link 
            to="/institute/request-form"
            className="inline-flex items-center px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-md transition-colors"
          >
            <PlusCircle className="h-5 w-5 mr-2" />
            Create New Request
          </Link>
        </div>
        
        {/* Pending Deliveries Section */}
        <div className="bg-white rounded-lg shadow-md mb-8">
          <div 
            className="p-4 border-b border-gray-200 flex justify-between items-center cursor-pointer"
            onClick={() => setShowPendingDeliveries(!showPendingDeliveries)}
          >
            <h2 className="text-xl font-semibold flex items-center">
              <Clock className="h-5 w-5 mr-2 text-red-500" />
              Pending Deliveries ({pendingDeliveries.length})
            </h2>
            {showPendingDeliveries ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
          </div>
          
          {showPendingDeliveries && (
            <div className="p-4">
              {pendingDeliveries.length > 0 ? (
                <div className="space-y-4">
                  {pendingDeliveries.map(delivery => (
                    <DeliveryCard key={delivery.id} {...delivery} />
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-4">No pending deliveries at the moment.</p>
              )}
            </div>
          )}
        </div>
        
        {/* Completed Deliveries Section */}
        <div className="bg-white rounded-lg shadow-md mb-8">
          <div 
            className="p-4 border-b border-gray-200 flex justify-between items-center cursor-pointer"
            onClick={() => setShowCompletedDeliveries(!showCompletedDeliveries)}
          >
            <h2 className="text-xl font-semibold flex items-center">
              <Package className="h-5 w-5 mr-2 text-green-500" />
              Completed Deliveries ({completedDeliveries.length})
            </h2>
            {showCompletedDeliveries ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
          </div>
          
          {showCompletedDeliveries && (
            <div className="p-4">
              {completedDeliveries.length > 0 ? (
                <div className="space-y-4">
                  {completedDeliveries.map(delivery => (
                    <DeliveryCard key={delivery.id} {...delivery} />
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-4">No completed deliveries yet.</p>
              )}
            </div>
          )}
        </div>
        
        {/* Upcoming Events Calendar */}
        <div className="bg-white rounded-lg shadow-md mb-8">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-red-500" />
              Upcoming Events
            </h2>
          </div>
          
          <div className="p-4">
            <div className="space-y-4">
              <div className="border-l-4 border-red-500 pl-4 py-2">
                <p className="font-semibold">Volunteer Teaching Session</p>
                <p className="text-sm text-gray-600">May 25, 2025 • 10:00 AM - 12:00 PM</p>
              </div>
              
              <div className="border-l-4 border-blue-500 pl-4 py-2">
                <p className="font-semibold">Monthly Health Checkup</p>
                <p className="text-sm text-gray-600">May 30, 2025 • 9:00 AM - 2:00 PM</p>
              </div>
              
              <div className="border-l-4 border-green-500 pl-4 py-2">
                <p className="font-semibold">Sports Day</p>
                <p className="text-sm text-gray-600">June 5, 2025 • All Day</p>
              </div>
            </div>
            
            <div className="mt-4">
              <Link 
                to="/institute/volunteer-requests"
                className="text-red-600 hover:text-red-800 font-medium text-sm"
              >
                Manage volunteer requests →
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InstituteDashboard;