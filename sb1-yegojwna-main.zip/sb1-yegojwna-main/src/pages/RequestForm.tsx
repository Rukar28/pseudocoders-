import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Package, Calendar, Clock, AlertTriangle } from 'lucide-react';
import Navbar from '../components/Navbar';

interface RequestItem {
  type: string;
  quantity: string;
  details: string;
}

const RequestForm: React.FC = () => {
  const navigate = useNavigate();
  const [isUrgent, setIsUrgent] = useState(false);
  const [expectedDate, setExpectedDate] = useState('');
  const [items, setItems] = useState<RequestItem[]>([
    { type: '', quantity: '', details: '' }
  ]);
  const [additionalNotes, setAdditionalNotes] = useState('');

  const handleItemChange = (index: number, field: keyof RequestItem, value: string) => {
    const updatedItems = [...items];
    updatedItems[index][field] = value;
    setItems(updatedItems);
  };

  const addItem = () => {
    setItems([...items, { type: '', quantity: '', details: '' }]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      const updatedItems = [...items];
      updatedItems.splice(index, 1);
      setItems(updatedItems);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real application, you would send this data to your backend
    console.log({
      isUrgent,
      expectedDate,
      items,
      additionalNotes
    });
    
    // Redirect back to dashboard
    navigate('/institute/dashboard');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar userType="institute" />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="bg-red-600 p-6">
            <h1 className="text-2xl font-bold text-white flex items-center">
              <Package className="h-6 w-6 mr-2" />
              Create Donation Request
            </h1>
            <p className="text-red-100 mt-1">
              Specify the items you need and when you need them
            </p>
          </div>
          
          <form onSubmit={handleSubmit} className="p-6">
            {/* Urgency Toggle */}
            <div className="mb-6">
              <div className="flex items-center">
                <button
                  type="button"
                  onClick={() => setIsUrgent(!isUrgent)}
                  className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    isUrgent ? 'bg-red-600' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      isUrgent ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
                <span className="ml-3 text-sm font-medium text-gray-900 flex items-center">
                  <AlertTriangle className={`h-4 w-4 mr-1 ${isUrgent ? 'text-red-600' : 'text-gray-400'}`} />
                  Mark as Urgent Request
                </span>
              </div>
              {isUrgent && (
                <p className="mt-2 text-sm text-red-600">
                  Urgent requests are highlighted to donors and prioritized for faster fulfillment.
                </p>
              )}
            </div>
            
            {/* Expected Date */}
            <div className="mb-6">
              <label htmlFor="expectedDate" className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                <Calendar className="h-4 w-4 mr-1 text-gray-500" />
                Expected Date
              </label>
              <input
                type="date"
                id="expectedDate"
                value={expectedDate}
                onChange={(e) => setExpectedDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                required
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
              />
              <p className="mt-1 text-sm text-gray-500">
                When do you need these items by?
              </p>
            </div>
            
            {/* Items Section */}
            <div className="mb-6">
              <h3 className="text-lg font-medium text-gray-900 mb-3">Requested Items</h3>
              
              {items.map((item, index) => (
                <div key={index} className="bg-gray-50 p-4 rounded-md mb-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label htmlFor={`itemType-${index}`} className="block text-sm font-medium text-gray-700 mb-1">
                        Item Type
                      </label>
                      <select
                        id={`itemType-${index}`}
                        value={item.type}
                        onChange={(e) => handleItemChange(index, 'type', e.target.value)}
                        required
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                      >
                        <option value="">Select item type</option>
                        <option value="groceries">Groceries</option>
                        <option value="clothing">Clothing</option>
                        <option value="medications">Medications</option>
                        <option value="meals">Full Day Meals</option>
                        <option value="school">School Supplies</option>
                        <option value="hygiene">Hygiene Products</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor={`quantity-${index}`} className="block text-sm font-medium text-gray-700 mb-1">
                        Quantity
                      </label>
                      <input
                        type="text"
                        id={`quantity-${index}`}
                        value={item.quantity}
                        onChange={(e) => handleItemChange(index, 'quantity', e.target.value)}
                        placeholder="e.g., 10kg, 20 sets, 15 boxes"
                        required
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor={`details-${index}`} className="block text-sm font-medium text-gray-700 mb-1">
                      Details
                    </label>
                    <input
                      type="text"
                      id={`details-${index}`}
                      value={item.details}
                      onChange={(e) => handleItemChange(index, 'details', e.target.value)}
                      placeholder="Specific requirements or preferences"
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                    />
                  </div>
                  
                  {items.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeItem(index)}
                      className="mt-3 text-sm text-red-600 hover:text-red-800"
                    >
                      Remove item
                    </button>
                  )}
                </div>
              ))}
              
              <button
                type="button"
                onClick={addItem}
                className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                + Add Another Item
              </button>
            </div>
            
            {/* Additional Notes */}
            <div className="mb-6">
              <label htmlFor="additionalNotes" className="block text-sm font-medium text-gray-700 mb-1">
                Additional Notes
              </label>
              <textarea
                id="additionalNotes"
                rows={3}
                value={additionalNotes}
                onChange={(e) => setAdditionalNotes(e.target.value)}
                placeholder="Any additional information that donors should know..."
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
              />
            </div>
            
            {/* Submit Button */}
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => navigate('/institute/dashboard')}
                className="mr-3 inline-flex justify-center py-2 px-4 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                Submit Request
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default RequestForm;