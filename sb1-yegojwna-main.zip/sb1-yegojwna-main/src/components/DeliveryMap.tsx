import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default marker icons in React Leaflet
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

interface Location {
  lat: number;
  lng: number;
  name: string;
  type: 'supplier' | 'institute' | 'transporter';
}

interface DeliveryMapProps {
  supplierLocation: Location;
  instituteLocation: Location;
  transporterLocation?: Location;
  estimatedArrival?: string;
}

// Component to automatically fit bounds to markers
const SetBoundsToMarkers = ({ locations }: { locations: Location[] }) => {
  const map = useMap();
  
  useEffect(() => {
    if (locations.length > 0) {
      const bounds = L.latLngBounds(locations.map(loc => [loc.lat, loc.lng]));
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [locations, map]);
  
  return null;
};

const DeliveryMap: React.FC<DeliveryMapProps> = ({
  supplierLocation,
  instituteLocation,
  transporterLocation,
  estimatedArrival
}) => {
  const locations = [
    supplierLocation,
    instituteLocation,
    ...(transporterLocation ? [transporterLocation] : [])
  ];

  const getMarkerColor = (type: Location['type']) => {
    switch (type) {
      case 'supplier':
        return 'blue';
      case 'institute':
        return 'green';
      case 'transporter':
        return 'red';
      default:
        return 'gray';
    }
  };

  return (
    <div className="rounded-lg overflow-hidden shadow-lg">
      <MapContainer 
        center={[instituteLocation.lat, instituteLocation.lng]} 
        zoom={13} 
        style={{ height: '400px', width: '100%' }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {locations.map((location, index) => (
          <Marker 
            key={index} 
            position={[location.lat, location.lng]}
            icon={L.divIcon({
              className: 'custom-div-icon',
              html: `<div style="background-color: ${getMarkerColor(location.type)}; width: 24px; height: 24px; border-radius: 50%; border: 2px solid white;"></div>`,
              iconSize: [24, 24],
              iconAnchor: [12, 12]
            })}
          >
            <Popup>
              <div>
                <strong>{location.name}</strong>
                <p>{location.type.charAt(0).toUpperCase() + location.type.slice(1)}</p>
                {location.type === 'transporter' && estimatedArrival && (
                  <p>ETA: {estimatedArrival}</p>
                )}
              </div>
            </Popup>
          </Marker>
        ))}
        
        <SetBoundsToMarkers locations={locations} />
      </MapContainer>
    </div>
  );
};

export default DeliveryMap;