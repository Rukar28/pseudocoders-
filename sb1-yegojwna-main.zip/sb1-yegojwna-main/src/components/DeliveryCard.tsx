import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Package, MapPin, Truck } from 'lucide-react';

interface DeliveryCardProps {
  id: string;
  status: 'pending' | 'in-progress' | 'completed';
  items: string[];
  quantity: string;
  supplier: string;
  estimatedDelivery: string;
  address: string;
}

const DeliveryCard: React.FC<DeliveryCardProps> = ({
  id,
  status,
  items,
  quantity,
  supplier,
  estimatedDelivery,
  address,
}) => {
  const statusColors = {
    'pending': 'bg-yellow-100 text-yellow-800',
    'in-progress': 'bg-blue-100 text-blue-800',
    'completed': 'bg-green-100 text-green-800',
  };

  const statusText = {
    'pending': 'Pending',
    'in-progress': 'In Progress',
    'completed': 'Completed',
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-4 border-l-4 border-red-500">
      <div className="flex justify-between items-start mb-3">
        <h3 className="font-semibold text-lg">Delivery #{id.slice(-6)}</h3>
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[status]}`}>
          {statusText[status]}
        </span>
      </div>
      
      <div className="space-y-2 mb-4">
        <div className="flex items-center text-sm text-gray-600">
          <Package className="h-4 w-4 mr-2 text-red-500" />
          <span>
            <strong>Items:</strong> {items.join(', ')} ({quantity})
          </span>
        </div>
        
        <div className="flex items-center text-sm text-gray-600">
          <MapPin className="h-4 w-4 mr-2 text-red-500" />
          <span>
            <strong>Supplier:</strong> {supplier}
          </span>
        </div>
        
        <div className="flex items-center text-sm text-gray-600">
          <Clock className="h-4 w-4 mr-2 text-red-500" />
          <span>
            <strong>Estimated Delivery:</strong> {estimatedDelivery}
          </span>
        </div>
        
        <div className="flex items-center text-sm text-gray-600">
          <MapPin className="h-4 w-4 mr-2 text-red-500" />
          <span>
            <strong>Delivery Address:</strong> {address}
          </span>
        </div>
      </div>
      
      <div className="flex justify-between mt-4">
        <Link 
          to={`/institute/delivery-tracking/${id}`}
          className="inline-flex items-center px-3 py-1.5 bg-gray-100 hover:bg-gray-200 rounded-md text-sm font-medium text-gray-700 transition-colors"
        >
          <Truck className="h-4 w-4 mr-1" />
          Track Delivery
        </Link>
        
        {status === 'completed' && (
          <Link 
            to={`/institute/feedback/${id}`}
            className="inline-flex items-center px-3 py-1.5 bg-red-100 hover:bg-red-200 rounded-md text-sm font-medium text-red-700 transition-colors"
          >
            Leave Feedback
          </Link>
        )}
      </div>
    </div>
  );
};

export default DeliveryCard;