import { DeliveryRequest, Transporter } from '../types';

// Mock transporter data
export const mockTransporter: Transporter = {
  id: 'trans-001',
  name: 'John Driver',
  email: 'john.driver@example.com',
  phone: '+91 9876543210',
  licenseNumber: 'DL-1234567890',
  vehicleModel: 'Maruti Suzuki Eeco',
  vehicleColor: 'White',
  licensePlate: 'MH 01 AB 1234',
  rating: 4.7,
  totalDeliveries: 156
};

// Mock delivery requests
export const mockDeliveryRequests: DeliveryRequest[] = [
  {
    id: 'del-001',
    status: 'pending',
    donorId: 'donor-001',
    donorName: 'Rahul Sharma',
    supplierId: 'sup-001',
    supplierName: 'Grocery World',
    supplierAddress: '123 Market Street, Mumbai',
    institutionId: 'inst-001',
    institutionName: 'Happy Children Orphanage',
    institutionAddress: '456 Care Lane, Mumbai',
    items: [
      {
        id: 'item-001',
        name: 'Rice',
        category: 'groceries',
        quantity: 25,
        unit: 'kg',
        price: 1250
      },
      {
        id: 'item-002',
        name: 'Dal',
        category: 'groceries',
        quantity: 10,
        unit: 'kg',
        price: 900
      }
    ],
    totalAmount: 2150,
    deliveryCharge: 150,
    pickupTime: '2025-06-15T10:00:00Z',
    estimatedDeliveryTime: '2025-06-15T12:00:00Z',
    distance: 8.5,
    otp: '4321',
    createdAt: '2025-06-14T15:30:00Z'
  },
  {
    id: 'del-002',
    status: 'in-progress',
    donorId: 'donor-002',
    donorName: 'Priya Patel',
    supplierId: 'sup-002',
    supplierName: 'MediCare Pharmacy',
    supplierAddress: '789 Health Avenue, Mumbai',
    institutionId: 'inst-002',
    institutionName: 'Sunshine Orphanage',
    institutionAddress: '101 Hope Street, Mumbai',
    items: [
      {
        id: 'item-003',
        name: 'Multivitamins',
        category: 'medication',
        quantity: 50,
        unit: 'bottles',
        price: 5000
      },
      {
        id: 'item-004',
        name: 'First Aid Kits',
        category: 'medication',
        quantity: 5,
        unit: 'kits',
        price: 2500
      }
    ],
    totalAmount: 7500,
    deliveryCharge: 200,
    pickupTime: '2025-06-15T14:00:00Z',
    estimatedDeliveryTime: '2025-06-15T16:00:00Z',
    distance: 12.3,
    otp: '7890',
    createdAt: '2025-06-14T09:45:00Z',
    transporterId: 'trans-001',
    currentLocation: {
      lat: 19.0760,
      lng: 72.8777
    }
  },
  {
    id: 'del-003',
    status: 'completed',
    donorId: 'donor-003',
    donorName: 'Amit Verma',
    supplierId: 'sup-003',
    supplierName: 'Fashion For All',
    supplierAddress: '222 Style Street, Mumbai',
    institutionId: 'inst-001',
    institutionName: 'Happy Children Orphanage',
    institutionAddress: '456 Care Lane, Mumbai',
    items: [
      {
        id: 'item-005',
        name: 'T-shirts',
        category: 'clothing',
        quantity: 30,
        unit: 'pieces',
        price: 3000
      },
      {
        id: 'item-006',
        name: 'Trousers',
        category: 'clothing',
        quantity: 30,
        unit: 'pieces',
        price: 4500
      }
    ],
    totalAmount: 7500,
    deliveryCharge: 180,
    pickupTime: '2025-06-14T11:00:00Z',
    estimatedDeliveryTime: '2025-06-14T13:00:00Z',
    actualDeliveryTime: '2025-06-14T12:45:00Z',
    distance: 7.8,
    otp: '5678',
    createdAt: '2025-06-13T16:20:00Z',
    transporterId: 'trans-001'
  }
];