export interface User {
  id: string;
  name: string;
  email: string;
  role: 'donor' | 'institution' | 'supplier' | 'transporter';
}

export interface Transporter {
  id: string;
  name: string;
  email: string;
  phone: string;
  licenseNumber: string;
  vehicleModel: string;
  vehicleColor: string;
  licensePlate: string;
  rating: number;
  totalDeliveries: number;
}

export interface DeliveryRequest {
  id: string;
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
  donorId: string;
  donorName: string;
  supplierId: string;
  supplierName: string;
  supplierAddress: string;
  institutionId: string;
  institutionName: string;
  institutionAddress: string;
  items: DeliveryItem[];
  totalAmount: number;
  deliveryCharge: number;
  pickupTime: string;
  estimatedDeliveryTime: string;
  actualDeliveryTime?: string;
  distance: number;
  otp: string;
  createdAt: string;
  transporterId?: string;
  currentLocation?: {
    lat: number;
    lng: number;
  };
}

export interface DeliveryItem {
  id: string;
  name: string;
  category: 'groceries' | 'clothing' | 'medication' | 'meals';
  quantity: number;
  unit: string;
  price: number;
}

export interface Location {
  lat: number;
  lng: number;
  address: string;
}

export interface PaymentDetails {
  id: string;
  deliveryId: string;
  amount: number;
  status: 'pending' | 'completed';
  paymentMethod: string;
  transactionId?: string;
  createdAt: string;
}