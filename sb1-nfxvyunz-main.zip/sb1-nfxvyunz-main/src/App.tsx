import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import TransporterLogin from './pages/transporter/TransporterLogin';
import TransporterDashboard from './pages/transporter/TransporterDashboard';
import DeliveryDetails from './pages/transporter/DeliveryDetails';
import DeliveryTracking from './pages/transporter/DeliveryTracking';
import PaymentDetails from './pages/transporter/PaymentDetails';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/transporter/login" element={<TransporterLogin />} />
        <Route path="/transporter/dashboard" element={<TransporterDashboard />} />
        <Route path="/transporter/delivery/:id" element={<DeliveryDetails />} />
        <Route path="/transporter/tracking/:id" element={<DeliveryTracking />} />
        <Route path="/transporter/payment/:id" element={<PaymentDetails />} />
      </Routes>
    </Router>
  );
}

export default App;