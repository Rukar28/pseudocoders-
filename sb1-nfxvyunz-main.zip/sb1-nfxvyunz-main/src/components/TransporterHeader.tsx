import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Truck, User, ChevronDown, LogOut, Settings } from 'lucide-react';
import { Transporter } from '../types';

interface TransporterHeaderProps {
  transporter: Transporter;
}

const TransporterHeader: React.FC<TransporterHeaderProps> = ({ transporter }) => {
  const navigate = useNavigate();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <Truck className="text-red-600 mr-2" size={28} />
          <h1 className="text-xl font-bold text-gray-800">Transporter Dashboard</h1>
        </div>
        
        <div className="relative">
          <button 
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="flex items-center space-x-2 text-gray-700 hover:text-gray-900 focus:outline-none"
          >
            <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">
              <User size={20} className="text-red-600" />
            </div>
            <span className="font-medium">{transporter.name}</span>
            <ChevronDown size={16} />
          </button>
          
          {isDropdownOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
              <a href="#" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                <User size={16} className="mr-2" />
                <span>Profile</span>
              </a>
              <a href="#" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                <Settings size={16} className="mr-2" />
                <span>Settings</span>
              </a>
              <a 
                href="/" 
                className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                onClick={(e) => {
                  e.preventDefault();
                  navigate('/');
                }}
              >
                <LogOut size={16} className="mr-2" />
                <span>Logout</span>
              </a>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default TransporterHeader;