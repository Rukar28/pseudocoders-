import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, MapPin, Navigation, Clock, CheckCircle, Phone } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { mockDeliveryRequests } from '../../data/mockData';
import { DeliveryRequest } from '../../types';

const DeliveryTracking: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [delivery, setDelivery] = useState<DeliveryRequest | undefined>(
    mockDeliveryRequests.find(d => d.id === id)
  );
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(
    delivery?.currentLocation || { lat: 19.0760, lng: 72.8777 }
  );
  const [remainingTime, setRemainingTime] = useState<number>(15);
  const [otpInput, setOtpInput] = useState('');
  
  useEffect(() => {
    if (!delivery || delivery.status !== 'in-progress') return;
    
    // Simulate location updates
    const interval = setInterval(() => {
      // Simulate movement towards destination
      if (currentLocation) {
        const institutionLat = 19.0822;
        const institutionLng = 72.8812;
        
        const newLat = currentLocation.lat + (institutionLat - currentLocation.lat) * 0.1;
        const newLng = currentLocation.lng + (institutionLng - currentLocation.lng) * 0.1;
        
        setCurrentLocation({ lat: newLat, lng: newLng });
        
        // Update remaining time
        setRemainingTime(prev => {
          const newTime = prev - 1;
          return newTime < 0 ? 0 : newTime;
        });
      }
    }, 5000);
    
    return () => clearInterval(interval);
  }, [delivery, currentLocation]);
  
  if (!delivery) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Delivery Not Found</h2>
          <p className="text-gray-600 mb-4">The delivery you're looking for doesn't exist.</p>
          <button 
            onClick={() => navigate('/transporter/dashboard')}
            className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }
  
  const handleCompleteDelivery = () => {
    // In a real app, you would verify the OTP and update the delivery status
    if (otpInput === delivery.otp) {
      alert('OTP verified! Delivery marked as completed.');
      navigate('/transporter/dashboard');
    } else {
      alert('Invalid OTP. Please check and try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <button 
          onClick={() => navigate(`/transporter/delivery/${delivery.id}`)}
          className="flex items-center text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft size={20} className="mr-2" />
          <span>Back to Delivery Details</span>
        </button>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Live Tracking</h2>
            <p className="text-gray-600 mb-6">
              Tracking delivery to {delivery.institutionName}
            </p>
            
            <div className="mb-6">
              {currentLocation && (
                <MapContainer center={[currentLocation.lat, currentLocation.lng]} zoom={13} scrollWheelZoom={false}>
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <Marker position={[currentLocation.lat, currentLocation.lng]}>
                    <Popup>
                      Current Location
                    </Popup>
                  </Marker>
                  <Marker position={[19.0822, 72.8812]}>
                    <Popup>
                      {delivery.institutionName}
                    </Popup>
                  </Marker>
                </MapContainer>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="bg-blue-50 p-4 rounded-lg flex items-start">
                <Navigation size={20} className="text-blue-500 mr-3 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-gray-700">Distance Remaining</p>
                  <p className="text-lg font-bold text-gray-900">{(delivery.distance * remainingTime / 15).toFixed(1)} km</p>
                </div>
              </div>
              <div className="bg-yellow-50 p-4 rounded-lg flex items-start">
                <Clock size={20} className="text-yellow-500 mr-3 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-gray-700">Estimated Arrival</p>
                  <p className="text-lg font-bold text-gray-900">
                    {remainingTime} mins
                  </p>
                </div>
              </div>
              <div className="bg-green-50 p-4 rounded-lg flex items-start">
                <MapPin size={20} className="text-green-500 mr-3 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-gray-700">Destination</p>
                  <p className="text-lg font-bold text-gray-900">{delivery.institutionName}</p>
                </div>
              </div>
            </div>
            
            <div className="border-t border-b py-6 mb-6">
              <h3 className="font-medium text-gray-900 mb-4">Delivery Information</h3>
              <div className="space-y-4">
                <div className="flex">
                  <div className="w-1/3 text-gray-600">Pickup From:</div>
                  <div className="w-2/3 font-medium">{delivery.supplierName}</div>
                </div>
                <div className="flex">
                  <div className="w-1/3 text-gray-600">Pickup Address:</div>
                  <div className="w-2/3">{delivery.supplierAddress}</div>
                </div>
                <div className="flex">
                  <div className="w-1/3 text-gray-600">Deliver To:</div>
                  <div className="w-2/3 font-medium">{delivery.institutionName}</div>
                </div>
                <div className="flex">
                  <div className="w-1/3 text-gray-600">Delivery Address:</div>
                  <div className="w-2/3">{delivery.institutionAddress}</div>
                </div>
                <div className="flex">
                  <div className="w-1/3 text-gray-600">Items:</div>
                  <div className="w-2/3">
                    {delivery.items.map((item, index) => (
                      <span key={item.id}>
                        {item.quantity} {item.unit} {item.name}
                        {index < delivery.items.length - 1 ? ', ' : ''}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row md:justify-between md:items-center space-y-4 md:space-y-0">
              <button 
                className="flex items-center justify-center bg-gray-200 text-gray-800 px-4 py-2 rounded-md hover:bg-gray-300 transition-colors"
              >
                <Phone size={18} className="mr-2" />
                <span>Call Institution</span>
              </button>
              
              <div className="flex space-x-4">
                <input
                  type="text"
                  value={otpInput}
                  onChange={(e) => setOtpInput(e.target.value)}
                  placeholder="Enter 4-digit OTP"
                  className="p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                  maxLength={4}
                />
                <button 
                  onClick={handleCompleteDelivery}
                  className="flex items-center bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors"
                >
                  <CheckCircle size={18} className="mr-2" />
                  <span>Complete Delivery</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryTracking;