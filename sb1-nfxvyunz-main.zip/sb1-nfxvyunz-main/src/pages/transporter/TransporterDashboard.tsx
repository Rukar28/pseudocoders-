import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Truck, Package, Clock, CheckCircle, MapPin, CreditCard, LogOut, ChevronDown, User } from 'lucide-react';
import { mockTransporter, mockDeliveryRequests } from '../../data/mockData';
import { DeliveryRequest } from '../../types';

const TransporterDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'pending' | 'in-progress' | 'completed'>('pending');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const pendingDeliveries = mockDeliveryRequests.filter(delivery => delivery.status === 'pending');
  const inProgressDeliveries = mockDeliveryRequests.filter(delivery => delivery.status === 'in-progress');
  const completedDeliveries = mockDeliveryRequests.filter(delivery => delivery.status === 'completed');

  const getFilteredDeliveries = () => {
    switch (activeTab) {
      case 'pending':
        return pendingDeliveries;
      case 'in-progress':
        return inProgressDeliveries;
      case 'completed':
        return completedDeliveries;
      default:
        return [];
    }
  };

  const handleDeliveryClick = (deliveryId: string) => {
    navigate(`/transporter/delivery/${deliveryId}`);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <Truck className="text-red-600 mr-2" size={28} />
            <h1 className="text-xl font-bold text-gray-800">Transporter Dashboard</h1>
          </div>
          
          <div className="relative">
            <button 
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center space-x-2 text-gray-700 hover:text-gray-900 focus:outline-none"
            >
              <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">
                <User size={20} className="text-red-600" />
              </div>
              <span className="font-medium">{mockTransporter.name}</span>
              <ChevronDown size={16} />
            </button>
            
            {isDropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
                <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Profile</a>
                <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Settings</a>
                <a href="/" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Logout</a>
              </div>
            )}
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StatCard 
            icon={<Package className="text-blue-500" size={24} />}
            title="Pending Deliveries"
            value={pendingDeliveries.length}
            bgColor="bg-blue-50"
          />
          <StatCard 
            icon={<Clock className="text-yellow-500" size={24} />}
            title="In Progress"
            value={inProgressDeliveries.length}
            bgColor="bg-yellow-50"
          />
          <StatCard 
            icon={<CheckCircle className="text-green-500" size={24} />}
            title="Completed"
            value={completedDeliveries.length}
            bgColor="bg-green-50"
          />
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="flex border-b">
            <button
              className={`flex-1 py-4 text-center font-medium ${activeTab === 'pending' ? 'text-red-600 border-b-2 border-red-600' : 'text-gray-600 hover:text-gray-800'}`}
              onClick={() => setActiveTab('pending')}
            >
              Pending Deliveries
            </button>
            <button
              className={`flex-1 py-4 text-center font-medium ${activeTab === 'in-progress' ? 'text-red-600 border-b-2 border-red-600' : 'text-gray-600 hover:text-gray-800'}`}
              onClick={() => setActiveTab('in-progress')}
            >
              In Progress
            </button>
            <button
              className={`flex-1 py-4 text-center font-medium ${activeTab === 'completed' ? 'text-red-600 border-b-2 border-red-600' : 'text-gray-600 hover:text-gray-800'}`}
              onClick={() => setActiveTab('completed')}
            >
              Completed
            </button>
          </div>
          
          <div className="p-6">
            {getFilteredDeliveries().length === 0 ? (
              <div className="text-center py-8">
                <Package size={48} className="mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-700 mb-2">No deliveries found</h3>
                <p className="text-gray-500">There are no deliveries in this category at the moment.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {getFilteredDeliveries().map((delivery) => (
                  <DeliveryCard 
                    key={delivery.id} 
                    delivery={delivery} 
                    onClick={() => handleDeliveryClick(delivery.id)} 
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
      
      {/* Sidebar / Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t md:top-0 md:left-0 md:bottom-0 md:w-64 md:border-r md:border-t-0">
        <div className="hidden md:flex items-center justify-center h-16 border-b">
          <Truck className="text-red-600 mr-2" size={24} />
          <h2 className="text-lg font-bold text-gray-800">DonationConnect</h2>
        </div>
        
        <div className="flex md:flex-col md:h-[calc(100vh-4rem)] md:justify-between">
          <div className="flex flex-1 justify-around md:flex-col md:space-y-1 md:p-2">
            <NavItem 
              icon={<Package size={20} />} 
              label="Deliveries" 
              isActive={true} 
              onClick={() => {}} 
            />
            <NavItem 
              icon={<MapPin size={20} />} 
              label="Tracking" 
              isActive={false} 
              onClick={() => navigate('/transporter/tracking/del-002')} 
            />
            <NavItem 
              icon={<CreditCard size={20} />} 
              label="Payments" 
              isActive={false} 
              onClick={() => navigate('/transporter/payment/del-002')} 
            />
          </div>
          
          <div className="hidden md:block p-4">
            <button 
              onClick={() => navigate('/')}
              className="flex items-center space-x-2 text-gray-700 hover:text-red-600 w-full"
            >
              <LogOut size={20} />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </nav>
    </div>
  );
};

interface StatCardProps {
  icon: React.ReactNode;
  title: string;
  value: number;
  bgColor: string;
}

const StatCard: React.FC<StatCardProps> = ({ icon, title, value, bgColor }) => {
  return (
    <div className={`${bgColor} rounded-lg shadow-sm p-6`}>
      <div className="flex items-center">
        <div className="mr-4">
          {icon}
        </div>
        <div>
          <h3 className="text-lg font-medium text-gray-700">{title}</h3>
          <p className="text-2xl font-bold text-gray-900">{value}</p>
        </div>
      </div>
    </div>
  );
};

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ icon, label, isActive, onClick }) => {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col md:flex-row items-center justify-center md:justify-start p-3 md:space-x-3 rounded-md ${
        isActive 
          ? 'text-red-600 bg-red-50 md:bg-red-50' 
          : 'text-gray-600 hover:text-red-600 hover:bg-red-50'
      }`}
    >
      {icon}
      <span className="text-xs md:text-sm font-medium">{label}</span>
    </button>
  );
};

interface DeliveryCardProps {
  delivery: DeliveryRequest;
  onClick: () => void;
}

const DeliveryCard: React.FC<DeliveryCardProps> = ({ delivery, onClick }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-blue-100 text-blue-800';
      case 'in-progress':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div 
      className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
      onClick={onClick}
    >
      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="font-medium text-gray-900">{delivery.institutionName}</h3>
          <p className="text-sm text-gray-600">{delivery.institutionAddress}</p>
        </div>
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(delivery.status)}`}>
          {delivery.status.charAt(0).toUpperCase() + delivery.status.slice(1)}
        </span>
      </div>
      
      <div className="flex items-center text-sm text-gray-600 mb-3">
        <Package size={16} className="mr-1" />
        <span>
          {delivery.items.length} {delivery.items.length === 1 ? 'item' : 'items'} | 
          {delivery.items.reduce((total, item) => total + item.quantity, 0)} units
        </span>
      </div>
      
      <div className="flex justify-between text-sm">
        <div className="flex items-center">
          <MapPin size={16} className="mr-1 text-gray-500" />
          <span>{delivery.distance} km</span>
        </div>
        <div className="flex items-center">
          <Clock size={16} className="mr-1 text-gray-500" />
          <span>
            {new Date(delivery.pickupTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
        <div className="font-medium text-gray-900">
          ₹{delivery.deliveryCharge}
        </div>
      </div>
    </div>
  );
};

export default TransporterDashboard;