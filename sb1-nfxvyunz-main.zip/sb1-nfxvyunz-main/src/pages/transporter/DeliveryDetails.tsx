import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Package, MapPin, Clock, CreditCard, CheckCircle, Truck, Building, Store } from 'lucide-react';
import { mockDeliveryRequests } from '../../data/mockData';

const DeliveryDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [otpInput, setOtpInput] = useState('');
  
  const delivery = mockDeliveryRequests.find(d => d.id === id);
  
  if (!delivery) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Delivery Not Found</h2>
          <p className="text-gray-600 mb-4">The delivery you're looking for doesn't exist.</p>
          <button 
            onClick={() => navigate('/transporter/dashboard')}
            className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }
  
  const handleAcceptDelivery = () => {
    // In a real app, you would update the delivery status in the backend
    alert('Delivery accepted! You can now proceed to pick up the items.');
    navigate('/transporter/dashboard');
  };
  
  const handleStartDelivery = () => {
    // In a real app, you would update the delivery status in the backend
    navigate(`/transporter/tracking/${delivery.id}`);
  };
  
  const handleCompleteDelivery = () => {
    // In a real app, you would verify the OTP and update the delivery status
    if (otpInput === delivery.otp) {
      alert('OTP verified! Delivery marked as completed.');
      navigate('/transporter/dashboard');
    } else {
      alert('Invalid OTP. Please check and try again.');
    }
  };
  
  const getStatusStepClass = (step: number, currentStatus: string) => {
    let currentStep = 1;
    if (currentStatus === 'in-progress') currentStep = 2;
    if (currentStatus === 'completed') currentStep = 3;
    
    if (step < currentStep) return 'bg-green-500 text-white border-green-500';
    if (step === currentStep) return 'bg-blue-500 text-white border-blue-500';
    return 'bg-white text-gray-500 border-gray-300';
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <button 
          onClick={() => navigate('/transporter/dashboard')}
          className="flex items-center text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft size={20} className="mr-2" />
          <span>Back to Dashboard</span>
        </button>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Delivery #{delivery.id.split('-')[1]}</h2>
            
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  delivery.status === 'pending' ? 'bg-blue-100 text-blue-800' :
                  delivery.status === 'in-progress' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-green-100 text-green-800'
                }`}>
                  {delivery.status.charAt(0).toUpperCase() + delivery.status.slice(1)}
                </span>
              </div>
              <div className="text-sm text-gray-600">
                Created on {new Date(delivery.createdAt).toLocaleDateString()}
              </div>
            </div>
            
            <div className="flex justify-between mb-8">
              <div className="w-full max-w-xs">
                <div className="flex items-center mb-2">
                  <Store size={20} className="text-gray-500 mr-2" />
                  <h3 className="font-medium text-gray-900">Pickup From</h3>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="font-medium text-gray-800">{delivery.supplierName}</p>
                  <p className="text-gray-600 text-sm">{delivery.supplierAddress}</p>
                  <p className="text-gray-600 text-sm mt-2">
                    Pickup time: {new Date(delivery.pickupTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
              
              <div className="w-full max-w-xs">
                <div className="flex items-center mb-2">
                  <Building size={20} className="text-gray-500 mr-2" />
                  <h3 className="font-medium text-gray-900">Deliver To</h3>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="font-medium text-gray-800">{delivery.institutionName}</p>
                  <p className="text-gray-600 text-sm">{delivery.institutionAddress}</p>
                  <p className="text-gray-600 text-sm mt-2">
                    Expected delivery: {new Date(delivery.estimatedDeliveryTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mb-8">
              <h3 className="font-medium text-gray-900 mb-4">Delivery Status</h3>
              <div className="flex items-center">
                <div className="relative flex items-center justify-center w-10 h-10 rounded-full border-2 mr-2 z-10 
                  ${getStatusStepClass(1, delivery.status)}">
                  <span>1</span>
                </div>
                <div className="flex-1 h-1 bg-gray-200 mx-2 relative">
                  <div className={`absolute top-0 left-0 h-full ${
                    delivery.status !== 'pending' ? 'bg-green-500' : 'bg-gray-200'
                  }`} style={{ width: '100%' }}></div>
                </div>
                <div className={`relative flex items-center justify-center w-10 h-10 rounded-full border-2 mr-2 z-10 
                  ${getStatusStepClass(2, delivery.status)}`}>
                  <span>2</span>
                </div>
                <div className="flex-1 h-1 bg-gray-200 mx-2 relative">
                  <div className={`absolute top-0 left-0 h-full ${
                    delivery.status === 'completed' ? 'bg-green-500' : 'bg-gray-200'
                  }`} style={{ width: '100%' }}></div>
                </div>
                <div className={`relative flex items-center justify-center w-10 h-10 rounded-full border-2 z-10 
                  ${getStatusStepClass(3, delivery.status)}`}>
                  <span>3</span>
                </div>
              </div>
              <div className="flex justify-between mt-2 text-sm">
                <div className="text-center w-1/3">
                  <p className="font-medium">Accepted</p>
                </div>
                <div className="text-center w-1/3">
                  <p className="font-medium">In Transit</p>
                </div>
                <div className="text-center w-1/3">
                  <p className="font-medium">Delivered</p>
                </div>
              </div>
            </div>
            
            <div className="mb-8">
              <h3 className="font-medium text-gray-900 mb-4">Items to Deliver</h3>
              <div className="bg-gray-50 rounded-lg overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {delivery.items.map((item) => (
                      <tr key={item.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{item.name}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-500">{item.category}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-500">{item.quantity} {item.unit}</div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            
            <div className="mb-8">
              <h3 className="font-medium text-gray-900 mb-4">Delivery Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg flex items-start">
                  <MapPin size={20} className="text-red-500 mr-3 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-gray-700">Distance</p>
                    <p className="text-lg font-bold text-gray-900">{delivery.distance} km</p>
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg flex items-start">
                  <Clock size={20} className="text-yellow-500 mr-3 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-gray-700">Estimated Time</p>
                    <p className="text-lg font-bold text-gray-900">
                      {Math.round(delivery.distance * 3)} mins
                    </p>
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg flex items-start">
                  <CreditCard size={20} className="text-green-500 mr-3 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-gray-700">Delivery Charge</p>
                    <p className="text-lg font-bold text-gray-900">₹{delivery.deliveryCharge}</p>
                  </div>
                </div>
              </div>
            </div>
            
            {delivery.status === 'pending' && (
              <div className="flex justify-center">
                <button 
                  onClick={handleAcceptDelivery}
                  className="bg-red-600 text-white px-6 py-3 rounded-md font-medium hover:bg-red-700 transition-colors"
                >
                  Accept Delivery
                </button>
              </div>
            )}
            
            {delivery.status === 'in-progress' && (
              <div className="space-y-6">
                <div className="flex justify-center">
                  <button 
                    onClick={handleStartDelivery}
                    className="bg-blue-600 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-700 transition-colors"
                  >
                    Start Navigation
                  </button>
                </div>
                
                <div className="border-t pt-6">
                  <h3 className="font-medium text-gray-900 mb-4">Complete Delivery</h3>
                  <p className="text-gray-600 mb-4">
                    Ask the institution representative for the OTP to complete the delivery.
                  </p>
                  <div className="flex space-x-4">
                    <input
                      type="text"
                      value={otpInput}
                      onChange={(e) => setOtpInput(e.target.value)}
                      placeholder="Enter 4-digit OTP"
                      className="flex-1 p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                      maxLength={4}
                    />
                    <button 
                      onClick={handleCompleteDelivery}
                      className="bg-green-600 text-white px-6 py-3 rounded-md font-medium hover:bg-green-700 transition-colors"
                    >
                      Verify & Complete
                    </button>
                  </div>
                </div>
              </div>
            )}
            
            {delivery.status === 'completed' && (
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
                  <CheckCircle size={32} className="text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Delivery Completed</h3>
                <p className="text-gray-600 mb-6">
                  This delivery was successfully completed on {new Date(delivery.actualDeliveryTime || '').toLocaleDateString()} at {new Date(delivery.actualDeliveryTime || '').toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.
                </p>
                <button 
                  onClick={() => navigate('/transporter/dashboard')}
                  className="bg-gray-200 text-gray-800 px-6 py-3 rounded-md font-medium hover:bg-gray-300 transition-colors"
                >
                  Back to Dashboard
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryDetails;