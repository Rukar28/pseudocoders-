import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, CreditCard, DollarSign, CheckCircle, AlertCircle } from 'lucide-react';
import { mockDeliveryRequests } from '../../data/mockData';

const PaymentDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [showSupplierPayment, setShowSupplierPayment] = useState(false);
  
  const delivery = mockDeliveryRequests.find(d => d.id === id);
  
  if (!delivery) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Delivery Not Found</h2>
          <p className="text-gray-600 mb-4">The delivery you're looking for doesn't exist.</p>
          <button 
            onClick={() => navigate('/transporter/dashboard')}
            className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }
  
  const handlePaySupplier = () => {
    // In a real app, you would process the payment to the supplier
    alert('Payment to supplier processed successfully!');
    setShowSupplierPayment(false);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <button 
          onClick={() => navigate('/transporter/dashboard')}
          className="flex items-center text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft size={20} className="mr-2" />
          <span>Back to Dashboard</span>
        </button>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Payment Details</h2>
            <p className="text-gray-600 mb-6">
              Payment information for delivery #{delivery.id.split('-')[1]} to {delivery.institutionName}
            </p>
            
            <div className="bg-gray-50 rounded-lg p-6 mb-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-medium text-gray-900">Payment Summary</h3>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  delivery.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {delivery.status === 'completed' ? 'Paid' : 'Pending'}
                </span>
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Items Total</span>
                  <span className="font-medium">₹{delivery.totalAmount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Delivery Charge</span>
                  <span className="font-medium">₹{delivery.deliveryCharge}</span>
                </div>
                <div className="border-t pt-4 flex justify-between">
                  <span className="text-gray-800 font-medium">Total Amount</span>
                  <span className="text-xl font-bold">₹{delivery.totalAmount + delivery.deliveryCharge}</span>
                </div>
              </div>
            </div>
            
            <div className="mb-8">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Payment Flow</h3>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <div className="flex">
                  <div className="mr-4">
                    <AlertCircle size={24} className="text-blue-500" />
                  </div>
                  <div>
                    <p className="text-gray-800 mb-2">How payments work:</p>
                    <ol className="list-decimal list-inside text-gray-600 space-y-1">
                      <li>Donor pays the total amount (items + delivery) to you</li>
                      <li>You collect the items from the supplier and pay them for the items</li>
                      <li>You keep the delivery charge as your payment</li>
                    </ol>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="border rounded-lg p-6">
                  <div className="flex items-center mb-4">
                    <DollarSign size={20} className="text-green-500 mr-2" />
                    <h4 className="font-medium text-gray-900">Amount Received</h4>
                  </div>
                  <p className="text-gray-600 mb-2">From: {delivery.donorName}</p>
                  <p className="text-2xl font-bold text-gray-900 mb-4">₹{delivery.totalAmount + delivery.deliveryCharge}</p>
                  <div className="flex items-center text-green-600">
                    <CheckCircle size={16} className="mr-1" />
                    <span className="text-sm">Received on {new Date(delivery.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
                
                <div className="border rounded-lg p-6">
                  <div className="flex items-center mb-4">
                    <CreditCard size={20} className="text-red-500 mr-2" />
                    <h4 className="font-medium text-gray-900">Amount to Pay Supplier</h4>
                  </div>
                  <p className="text-gray-600 mb-2">To: {delivery.supplierName}</p>
                  <p className="text-2xl font-bold text-gray-900 mb-4">₹{delivery.totalAmount}</p>
                  {delivery.status === 'in-progress' ? (
                    <button 
                      onClick={() => setShowSupplierPayment(true)}
                      className="bg-red-600 text-white px-4 py-2 rounded-md text-sm hover:bg-red-700 transition-colors"
                    >
                      Pay to Supplier
                    </button>
                  ) : (
                    <div className="flex items-center text-green-600">
                      <CheckCircle size={16} className="mr-1" />
                      <span className="text-sm">Paid on {new Date(delivery.actualDeliveryTime || '').toLocaleDateString()}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Your Earnings</h3>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 mb-1">Delivery Charge</p>
                  <p className="text-2xl font-bold text-gray-900">₹{delivery.deliveryCharge}</p>
                </div>
                <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                  {delivery.status === 'completed' ? 'Earned' : 'Pending'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {showSupplierPayment && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Pay to Supplier</h3>
            <p className="text-gray-600 mb-6">
              You are about to pay ₹{delivery.totalAmount} to {delivery.supplierName} for the items.
            </p>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-gray-700 mb-2" htmlFor="payment-method">Payment Method</label>
                <select 
                  id="payment-method"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                  <option value="cash">Cash</option>
                  <option value="upi">UPI</option>
                  <option value="bank">Bank Transfer</option>
                </select>
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2" htmlFor="payment-note">Note (Optional)</label>
                <textarea
                  id="payment-note"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                  rows={3}
                  placeholder="Add any notes about the payment..."
                ></textarea>
              </div>
            </div>
            
            <div className="flex justify-end space-x-4">
              <button 
                onClick={() => setShowSupplierPayment(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-100 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handlePaySupplier}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
              >
                Confirm Payment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PaymentDetails;