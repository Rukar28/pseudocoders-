import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Truck, Building, Store, Heart } from 'lucide-react';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient text-white">
      <div className="container mx-auto px-4 py-12">
        <header className="flex justify-between items-center mb-16">
          <div className="flex items-center">
            <Heart className="text-red-500 mr-2" size={32} />
            <h1 className="text-2xl font-bold">DonationConnect</h1>
          </div>
          <nav>
            <ul className="flex space-x-6">
              <li><a href="#about" className="hover:text-red-500 transition-colors">About</a></li>
              <li><a href="#how-it-works" className="hover:text-red-500 transition-colors">How It Works</a></li>
              <li><a href="#contact" className="hover:text-red-500 transition-colors">Contact</a></li>
            </ul>
          </nav>
        </header>

        <main>
          <section className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Connecting Donors with Orphanages</h2>
            <p className="text-xl text-gray-300 mb-10 max-w-3xl mx-auto">
              A platform that bridges the gap between donors, orphanages, suppliers, and transporters to ensure efficient and transparent donation delivery.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
              <RoleCard 
                title="Donor" 
                icon={<Heart size={48} className="text-red-500" />} 
                description="Donate goods and track your contributions"
                onClick={() => navigate('/donor/login')}
              />
              <RoleCard 
                title="Institution" 
                icon={<Building size={48} className="text-red-500" />} 
                description="Request donations and manage resources"
                onClick={() => navigate('/institution/login')}
              />
              <RoleCard 
                title="Supplier" 
                icon={<Store size={48} className="text-red-500" />} 
                description="Provide goods for donation at competitive prices"
                onClick={() => navigate('/supplier/login')}
              />
              <RoleCard 
                title="Transporter" 
                icon={<Truck size={48} className="text-red-500" />} 
                description="Deliver donations from suppliers to institutions"
                onClick={() => navigate('/transporter/login')}
              />
            </div>
          </section>
        </main>
      </div>
    </div>
  );
};

interface RoleCardProps {
  title: string;
  icon: React.ReactNode;
  description: string;
  onClick: () => void;
}

const RoleCard: React.FC<RoleCardProps> = ({ title, icon, description, onClick }) => {
  return (
    <div 
      className="bg-gray-800 p-6 rounded-lg shadow-lg hover:bg-gray-700 transition-colors cursor-pointer"
      onClick={onClick}
    >
      <div className="flex justify-center mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </div>
  );
};

export default LandingPage;